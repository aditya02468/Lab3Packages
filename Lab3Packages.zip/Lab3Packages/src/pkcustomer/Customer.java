package pkcustomer;

import pkaccount.sb.SBAccount;

import java.util.Scanner;

public class Customer {
    public int custId;
    public String name;
    public String address;
    SBAccount sbAccount;

    public Customer(int accNum,double bal,int custId,String name,String address ) {
        this.custId = custId;
        this.name = name;
        this.address = address;
        sbAccount=new SBAccount(accNum,bal);
    }
    public void transaction(int type){
        Scanner scanner=new Scanner(System.in);
        double amount;
        if(type==1){ // calling deposit method
            System.out.print("amount to deposit: ");
            amount= scanner.nextDouble();
            scanner.nextLine();
            sbAccount.deposit(amount);
        } else if(type==2){ // calling withDraw method
            System.out.print("amount to withDraw: ");
            amount= scanner.nextDouble();
            scanner.nextLine();
            sbAccount.withDraw(amount);
        }else if(type==3){
            sbAccount.calcInterest();
        }else
            System.out.println("Invalid type of transaction");
    }
    public void displayCustDetails(){
        System.out.println("\t====Customer Details====");
        System.out.println("Customer Name: "+name);
        System.out.println("Customer ID: "+custId);
        System.out.println("Customer address: "+address);
    }

    public int getCustId() {return custId;}
}

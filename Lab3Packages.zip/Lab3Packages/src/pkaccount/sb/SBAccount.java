package pkaccount.sb;

import pkaccount.Account;
import pkbanking.pkinterface.*;

public class SBAccount extends Account {
    public SBAccount(int accNumber, double initBalance) {
        super(accNumber, initBalance);
    }

    public void withDraw(double amt) {
        if(balance-amt>Transaction.minBalance){
            balance-=amt;
            System.out.println("Amount "+amt+" is withDrawn successfully");
        }else
            System.out.println("WithDraw amount exceeds minimum balance");
    }

    public void deposit(double amt) {
        if(amt>0){
            balance+=amt;
            System.out.println("Amount "+amt+" is deposited successfully");
            System.out.println("Balance: "+balance);
        }else
            System.out.println("Deposit a valid amount");
    }

    public void calcInterest() {
        balance+=balance*InterestRate.sbRate;
    }
}

package pkaccount;

public abstract class Account {
    protected int accNumber;
    protected double balance;

    //constructor
    public Account(int accNumber, double balance) {
        this.accNumber = accNumber;
        this.balance = balance;
    }
}

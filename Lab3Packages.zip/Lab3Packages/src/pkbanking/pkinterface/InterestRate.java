package pkbanking.pkinterface;

public abstract class InterestRate {
   public static double sbRate=0.04;
    abstract void calcInterest();
}

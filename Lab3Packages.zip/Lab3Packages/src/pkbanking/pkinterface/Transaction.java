package pkbanking.pkinterface;

public abstract class Transaction {
     public static int minBalance=500;
     // methods
    abstract void withDraw(double amt);
   abstract void deposit(double amt);
}

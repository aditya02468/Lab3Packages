import pkcustomer.Customer;

import java.util.Scanner;

public class BankDemo {
    public static Scanner scanner=new Scanner(System.in);
    public static void main(String[] args) {
        Customer [] customers=new Customer[5];
        customers[0]=new Customer(1234,12000.23,224,"aditya","St.Berg");
        customers[1]=new Customer(5678,15000.43,225,"Avinash","Clock Street");
        customers[2]=new Customer(1456,1234.56,226,"Midhun","Down Town");
        customers[3]=new Customer(8912,56784.23,227,"Prakash","Royal Mile");
        customers[4]=new Customer(3452,6789.45,228,"Michel","Orchard Road");

        System.out.print("Customer ID to do transactions: ");
        int id=scanner.nextInt();
        scanner.nextLine();
        Customer customerDetails=findCustomerById(customers,id);
        if(customerDetails!=null){
            if(customerDetails.getCustId()==id) {
                customerDetails.displayCustDetails();
                transactions(customerDetails);
            }
        }else
            System.out.println("Customer with ID: "+id+" is not found");
    }
    public static void transactions(Customer customer){
        System.out.println("\t1-Deposit");
        System.out.println("\t2-WithDraw");
        System.out.println("\t3-Calculate Interest");
        System.out.print("type of transaction: ");
        int type=scanner.nextInt();
        scanner.nextLine();
        customer.transaction(type);
    }
    public static Customer findCustomerById(Customer [] customers,int id){
        for(Customer customer:customers){
            if(customer.getCustId()==id)
                return customer;
        }
        return null;
    }
}
